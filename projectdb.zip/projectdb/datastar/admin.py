from django.contrib import admin
from . import models

admin.site.register(models.Program)
admin.site.register(models.Project_Area)
admin.site.register(models.LOB)
admin.site.register(models.SubLOB)
admin.site.register(models.Project)
admin.site.register(models.SubProject)
admin.site.register(models.ProjectReview)
