from django.contrib.auth.decorators import login_required
from django.core.exceptions import PermissionDenied
from django.urls import reverse
from django.http import HttpResponseRedirect
from django.shortcuts import get_object_or_404
from django.utils.decorators import method_decorator
from django.views.generic import DetailView
from django.views.generic.edit import CreateView, UpdateView

from .models import Program, Project_Area, LOB, SubLOB, Project, SubProject, ProjectReview
from .forms import ProjectForm, SubProjectForm

# Security Mixins

class LoginRequiredMixin(object):
    @method_decorator(login_required())
    def dispatch(self, *args, **kwargs):
        return super(LoginRequiredMixin, self).dispatch(*args, **kwargs)

class CheckIsOwnerMixin(object):
    def get_object(self, *args, **kwargs):
        obj = super(CheckIsOwnerMixin, self).get_object(*args, **kwargs)
        if not obj.user == self.request.user:
            raise PermissionDenied
        return obj

class LoginRequiredCheckIsOwnerUpdateView(LoginRequiredMixin, CheckIsOwnerMixin, UpdateView):
    template_name = 'datastar/form.html'

# HTML Views

class ProjectDetail(DetailView):
    model = Project
    template_name = 'datastar/project_detail.html'

    def get_context_data(self, **kwargs):
        context = super(ProjectDetail, self).get_context_data(**kwargs)
        #context['RATING_CHOICES'] = RestaurantReview.RATING_CHOICES
        return context

class ProjectCreate(LoginRequiredMixin, CreateView):
    model = Project
    template_name = 'datastar/form.html'
    form_class = ProjectForm

    def form_valid(self, form):
        form.instance.user = self.request.user
        return super(ProjectCreate, self).form_valid(form)

class SubProjectCreate(LoginRequiredMixin, CreateView):
    model = SubProject
    template_name = 'datastar/form.html'
    form_class = SubProjectForm

    def form_valid(self, form):
        form.instance.user = self.request.user
        form.instance.project = Project.objects.get(id=self.kwargs['pk'])
        return super(SubProjectCreate, self).form_valid(form)

def review(request, pk):
    project = get_object_or_404(Project, pk=pk)
    if ProjectReview.objects.filter(project=project, user=request.user).exists():
        ProjectReview.objects.get(project=project, user=request.user).delete()
    new_review = ProjectReview(
        comment=request.POST['comment'],
        user=request.user,
        project=project)
    new_review.save()
    return HttpResponseRedirect(reverse('datastar:project_detail', args=(project.id,)))

