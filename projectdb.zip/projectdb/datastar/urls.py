from django.conf.urls import url
from django.contrib.auth.decorators import login_required

from django.utils import timezone
from django.views.generic import DetailView, ListView, UpdateView
from .models import Program, Project_Area, LOB, SubLOB, Project, SubProject
from .forms import ProjectForm, SubProjectForm
from .views import ProjectCreate, SubProjectCreate, ProjectDetail, review, LoginRequiredCheckIsOwnerUpdateView

urlpatterns = [
    # List latest 5 project: /datastar/
    url(r'^$',
        ListView.as_view(
            queryset=Project.objects.filter(date__lte=timezone.now()).order_by('-date')[:5],
            context_object_name='latest_project_list',
            template_name='datastar/project_list.html'),
        name='project_list'),

    # Project details, ex.: /datastar/project/1/
    url(r'^project/(?P<pk>\d+)/$',
        ProjectDetail.as_view(),
        name='project_detail'),

    # Subproject details, ex: /datastar/project/1/subproject/1/
    url(r'^project/(?P<pkr>\d+)/subproject/(?P<pk>\d+)/$',
        DetailView.as_view(
            model=SubProject,
            template_name='datastar/subproject_detail.html'),
        name='subproject_detail'),

    # Create a Project, /datastar/project/create/
    url(r'^project/create/$',
        ProjectCreate.as_view(),
        name='project_create'),

    # Edit Project details, ex.: /datastar/project/1/edit/
    url(r'^project/(?P<pk>\d+)/edit/$',
        LoginRequiredCheckIsOwnerUpdateView.as_view(
            model=Project,
            form_class=ProjectForm),
        name='project_edit'),

    # Create a SubProject dish, ex.: /datastar/project/1/subproject/create/
    url(r'^project/(?P<pk>\d+)/subproject/create/$',
        SubProjectCreate.as_view(),
        name='subproject_create'),

    # Edit SubProject  details, ex.: /datastar/project/1/subproject/1/edit/
    url(r'^project/(?P<pkr>\d+)/subproject/(?P<pk>\d+)/edit/$',
        LoginRequiredCheckIsOwnerUpdateView.as_view(
            model=SubProject,
            form_class=SubProjectForm),
        name='subproject_edit'),

    # Create a Project review, ex.: /datastar/project/1/reviews/create/
    url(r'^project/(?P<pk>\d+)/reviews/create/$',
        review,
        name='review_create'),
]
