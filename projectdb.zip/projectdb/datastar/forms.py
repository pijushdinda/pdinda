from django.forms import ModelForm
from .models import Project, SubProject

class ProjectForm(ModelForm):
    class Meta:
        model = Project
        exclude = ('user', 'date',)

class SubProjectForm(ModelForm):
    class Meta:
        model = SubProject
        exclude = ('user', 'date', 'project',)
