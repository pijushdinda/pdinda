from __future__ import unicode_literals

from django.db import models
from django.contrib.auth.models import User
from django.urls import reverse
from datetime import date

class Program(models.Model):
    Prog_NM = models.CharField(max_length=200)
    Prog_Descr = models.CharField(max_length=200)
    
    def __str__(self):
       return u"%s" % self.Prog_NM

class Project_Area(models.Model):
    Proj_Area_NM = models.CharField(max_length=50)

    def __str__(self):
        return u"%s" % self.Proj_Area_NM
    
class LOB(models.Model):
    name = models.CharField(max_length=55)

    def __str__(self):
       return u"%s" % self.name

class SubLOB(models.Model):
    name = models.CharField(max_length=55)

    def __str__(self):
       return u"%s" % self.name
        

class Project(models.Model):
    dna_intake_id = models.IntegerField(blank=True)
    name = models.CharField(max_length=120)
    project_area = models.ForeignKey(Project_Area, on_delete=models.CASCADE, blank=True)
    program = models.ForeignKey(Program, on_delete=models.CASCADE, blank=True)
    lob = models.ForeignKey(LOB, blank=True, null=True, on_delete=models.SET_NULL)
    sublob = models.ForeignKey(SubLOB, blank=True, null=True, on_delete=models.SET_NULL)
    user = models.ForeignKey(User, on_delete=models.DO_NOTHING,default=1)
    date = models.DateField(default=date.today)

    def __str__(self):
        return u"%s" % self.dna_intake_id

    def get_absolute_url(self):
        return reverse('datastar:project_detail', kwargs={'pk': self.pk})

class SubProject(models.Model):
    project = models.ForeignKey(Project, on_delete=models.DO_NOTHING, null=True, related_name='projects')
    name = models.CharField(max_length=120)
    description = models.TextField(blank=True, null=True)
    pm = models.CharField(max_length=120, blank=True, null=True)
    bsa = models.CharField(max_length=120, blank=True, null=True)
    stdate = models.DateField(default=date.today)
    enddate = models.DateField(default=date.today)
    estimated = models.BooleanField(default=False, blank=True)
    approved = models.BooleanField(default=False, blank=True)
    forecasted = models.BooleanField(default=False, blank=True)
    l0_cost = models.DecimalField('Dollar amount', max_digits=8, decimal_places=2, blank=True, null=True)
    user = models.ForeignKey(User, on_delete=models.DO_NOTHING, default=1)
    
    def __str__(self):
        return u"%s" % self.name

    def get_absolute_url(self):
        return reverse('datastar:subproject_detail', kwargs={'pkr': self.project.pk, 'pk': self.pk})

class Review(models.Model):
    comment = models.TextField(blank=True, null=True)
    user = models.ForeignKey(User, on_delete=models.DO_NOTHING, default=1)
    date = models.DateField(default=date.today)

    class Meta:
        abstract = True

class ProjectReview(Review):
    project = models.ForeignKey(Project, on_delete=models.DO_NOTHING)

    class Meta:
        unique_together = ("project", "user")
